#!/bin/bash
set -e
pegasus_lite_version_major="5"
pegasus_lite_version_minor="0"
pegasus_lite_version_patch="1"
pegasus_lite_enforce_strict_wp_check="true"
pegasus_lite_version_allow_wp_auto_download="true"


. pegasus-lite-common.sh

pegasus_lite_init

# cleanup in case of failures
trap pegasus_lite_signal_int INT
trap pegasus_lite_signal_term TERM
trap pegasus_lite_unexpected_exit EXIT

printf "\n########################[Pegasus Lite] Setting up workdir ########################\n"  1>&2
# work dir
pegasus_lite_setup_work_dir

printf "\n##############[Pegasus Lite] Figuring out the worker package to use ##############\n"  1>&2
# figure out the worker package to use
pegasus_lite_worker_package

pegasus_lite_section_start stage_in
printf "\n###################### Staging in input data and executables ######################\n"  1>&2
# stage in data and executables
pegasus-transfer --threads 1  --symlink  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_29.txt",
   "id": 1,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_29.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_29.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_24.txt",
   "id": 2,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_24.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_24.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_16.txt",
   "id": 3,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_16.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_16.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_32.txt",
   "id": 4,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_32.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_32.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_6.txt",
   "id": 5,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_6.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_6.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_25.txt",
   "id": 6,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_25.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_25.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_2.txt",
   "id": 7,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_2.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_2.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_10.txt",
   "id": 8,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_10.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_10.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_12.txt",
   "id": 9,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_12.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_12.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_3.txt",
   "id": 10,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_3.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_3.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_23.txt",
   "id": 11,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_23.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_23.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_8.txt",
   "id": 12,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_8.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_8.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_20.txt",
   "id": 13,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_20.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_20.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_19.txt",
   "id": 14,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_19.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_19.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_15.txt",
   "id": 15,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_15.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_15.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_28.txt",
   "id": 16,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_28.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_28.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_7.txt",
   "id": 17,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_7.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_7.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_11.txt",
   "id": 18,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_11.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_11.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_30.txt",
   "id": 19,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_30.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_30.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_18.txt",
   "id": 20,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_18.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_18.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_9.txt",
   "id": 21,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_9.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_9.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_21.txt",
   "id": 22,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_21.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_21.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_14.txt",
   "id": 23,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_14.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_14.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_27.txt",
   "id": 24,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_27.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_27.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_4.txt",
   "id": 25,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_4.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_4.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_17.txt",
   "id": 26,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_17.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_17.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_31.txt",
   "id": 27,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_31.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_31.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_1.txt",
   "id": 28,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_1.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_1.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_22.txt",
   "id": 29,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_22.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_22.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_13.txt",
   "id": 30,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/00/2_13.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_13.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_5.txt",
   "id": 31,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_5.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_5.txt" }
   ] }
 ,
 { "type": "transfer",
   "linkage": "input",
   "lfn": "2_26.txt",
   "id": 32,
   "src_urls": [
     { "site_label": "staging", "url": "http://10.100.101.107/~panorama//panorama/pegasus/edge-cloud/run0009/00/01/2_26.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/2_26.txt" }
   ] }
]
eof

pegasus_lite_section_end stage_in
set +e
job_ec=0
pegasus_lite_section_start task_execute
printf "\n######################[Pegasus Lite] Executing the user task ######################\n"  1>&2
pegasus-kickstart  -n keg -N merge -R condorpool  -s merge.txt=merge.txt -L edge-cloud -T 2021-11-25T02:53:08+00:00 /usr/bin/pegasus-keg -T 60 -o merge.txt=250M
job_ec=$?
pegasus_lite_section_end task_execute
set -e
pegasus_lite_section_start stage_out
printf "\n############################ Staging out output files ############################\n"  1>&2
# stage out
pegasus-transfer --threads 1  1>&2 << 'eof'
[
 { "type": "transfer",
   "linkage": "output",
   "lfn": "merge.txt",
   "id": 1,
   "src_urls": [
     { "site_label": "condorpool", "url": "file://$PWD/merge.txt", "checkpoint": "false" }
   ],
   "dest_urls": [
     { "site_label": "staging", "url": "scp://panorama@10.100.101.107/home/panorama/public_html//panorama/pegasus/edge-cloud/run0009/00/01/merge.txt" }
   ] }
]
eof

pegasus_lite_section_end stage_out

set -e


# clear the trap, and exit cleanly
trap - EXIT
pegasus_lite_final_exit

